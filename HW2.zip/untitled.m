gama1=0;
gama2=0;
g=981;
a=[0.071 0.057 0.071 0.057];
A=[28 32 28 32];
h0=[12.4 12.7 1.8 1.4];

for i=1:4
    t(i)=(A(i)/a(i)).*(sqrt((2.*h0(i))/g));%time constant for each tank
end
c1=t(1)./A(1);
c2=t(2)./A(2);
G11=tf(gama1.*c1,[t(1),1]);
G12=tf((1-gama2).*c1,[t(1).*t(3),t(1)+t(3),1]);
G21=tf((1-gama1).*c2,[t(2).*t(4),t(2)+t(4),1]);
G22=tf(gama2.*c2,[t(2),1]);
G=[G11 G12;G21 G22]